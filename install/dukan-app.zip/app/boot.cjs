// electron/boot.ts
var import_electron = require("electron");
var import_node_fs = require("node:fs");
var import_node_path = require("node:path");
var SHIPPED_BRAIN = (0, import_node_path.join)(__dirname, "brain");
if (process.env.POS_USER_DATA) {
  import_electron.app.setPath("userData", process.env.POS_USER_DATA);
}
function stateFile() {
  return (0, import_node_path.join)(import_electron.app.getPath("userData"), "brain", "state.json");
}
function shippedVersion() {
  try {
    const file = (0, import_node_path.join)(SHIPPED_BRAIN, "version.txt");
    if ((0, import_node_fs.existsSync)(file)) return (0, import_node_fs.readFileSync)(file, "utf8").trim();
  } catch {
  }
  return "0.0.0";
}
function versionLessThan(a, b) {
  const pa = a.split(".").map((n) => Number(n) || 0);
  const pb = b.split(".").map((n) => Number(n) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i += 1) {
    const left = pa[i] ?? 0;
    const right = pb[i] ?? 0;
    if (left !== right) return left < right;
  }
  return false;
}
function readState() {
  try {
    const file = stateFile();
    if (!(0, import_node_fs.existsSync)(file)) return {};
    return JSON.parse((0, import_node_fs.readFileSync)(file, "utf8"));
  } catch {
    return {};
  }
}
function writeState(state) {
  try {
    (0, import_node_fs.writeFileSync)(stateFile(), JSON.stringify(state), "utf8");
  } catch {
  }
}
function chooseBrain() {
  let state;
  try {
    state = readState();
  } catch {
    return SHIPPED_BRAIN;
  }
  if (!state.version) return SHIPPED_BRAIN;
  const candidate = (0, import_node_path.join)(import_electron.app.getPath("userData"), "brain", state.version);
  const entry = (0, import_node_path.join)(candidate, "main.cjs");
  if (!(0, import_node_fs.existsSync)(entry)) {
    writeState({});
    return SHIPPED_BRAIN;
  }
  if (!versionLessThan(shippedVersion(), state.version)) {
    try {
      (0, import_node_fs.rmSync)(candidate, { recursive: true, force: true });
    } catch {
    }
    writeState({});
    return SHIPPED_BRAIN;
  }
  if (state.verified === true) return candidate;
  if ((state.tries ?? 0) < 1) {
    writeState({ version: state.version, verified: false, tries: 1 });
    return candidate;
  }
  try {
    (0, import_node_fs.rmSync)(candidate, { recursive: true, force: true });
  } catch {
  }
  writeState({});
  return SHIPPED_BRAIN;
}
var brain = SHIPPED_BRAIN;
try {
  brain = chooseBrain();
} catch {
  brain = SHIPPED_BRAIN;
}
process.env.POS_BRAIN_DIR = brain;
process.env.POS_SHIPPED_BRAIN_DIR = SHIPPED_BRAIN;
try {
  require((0, import_node_path.join)(brain, "main.cjs"));
} catch (error) {
  console.error("[pos] \u0909\u0924\u0930\u093E \u0939\u0941\u0906 \u0926\u093F\u092E\u093E\u0917\u093C \u0928\u0939\u0940\u0902 \u091A\u0932\u093E, \u092A\u0941\u0930\u093E\u0928\u0947 \u092A\u0930 \u0932\u094C\u091F \u0930\u0939\u0947 \u0939\u0948\u0902:", error);
  try {
    writeState({});
  } catch {
  }
  process.env.POS_BRAIN_DIR = SHIPPED_BRAIN;
  require((0, import_node_path.join)(SHIPPED_BRAIN, "main.cjs"));
}
