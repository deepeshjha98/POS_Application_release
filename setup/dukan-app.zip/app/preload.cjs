// electron/preload.ts
var import_electron = require("electron");
import_electron.contextBridge.exposeInMainWorld("posHost", {
  call: (method, args) => import_electron.ipcRenderer.invoke("pos:call", method, args),
  updateCheck: () => import_electron.ipcRenderer.invoke("pos:update-check"),
  updateApply: () => import_electron.ipcRenderer.invoke("pos:update-apply"),
  relaunch: () => import_electron.ipcRenderer.invoke("pos:relaunch"),
  openDataFolder: () => import_electron.ipcRenderer.invoke("pos:open-data-folder")
});
